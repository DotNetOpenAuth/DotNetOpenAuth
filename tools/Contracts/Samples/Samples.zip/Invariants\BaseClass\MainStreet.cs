﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace BasicBankAccount {

  public class BankAccount {

    protected int balance;

    [ContractInvariantMethod]
    private void GoodAccount() {
      Contract.Invariant(0 <= balance);
    }

    public virtual int Balance {
      get { return balance; }
    }

    public virtual void Withdraw(int amount) {
      Contract.Requires(0 < amount);
      Contract.Requires(amount < Balance);
      this.balance -= amount;
    }

    public virtual void Deposit(int amount) {
      Contract.Requires(0 < amount);
      this.balance += amount;
    }

  }
}
