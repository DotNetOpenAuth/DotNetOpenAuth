﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
  class NullableProtocol
  {
    /// <summary>
    /// The simplest protocol is associated with Nullable<typeparamref name=">T"/> types.
    /// In order to get the value of a nullable, its HasValue property must be true.
    /// </summary>
    public static int Sum(int? optX, int? optY)
    {
      var result = 0;

      result += optX.Value;

      if (optY.HasValue)
      {
        result += optY.Value;
      }
      return result;
    }
  }
}
