﻿using System;
using System.IO;
using System.Diagnostics.Contracts;

public class ClassWithProtocol
{
  public enum S
  {
    NotReady, Initialized, Computed
  }

  private S _state;
  public S State
  {
    get
    {
      return _state;
    }
  }

  [ContractInvariantMethod]
  private void ObjectInvariant()
  {
    Contract.Invariant(_state != S.Computed || _computedData != null);
  }

  public ClassWithProtocol()
  {
    Contract.Ensures(this.State == S.NotReady);
    _state = S.NotReady;
  }

  string _data;

  public void Initialize(string data)
  {
    Contract.Requires(State == S.NotReady);
    Contract.Ensures(State == S.Initialized);

    this._data = data;
    _state = S.Initialized;
  }

  public bool Compute(string prefix)
  {
    Contract.Requires(prefix != null);
    Contract.Requires(State == S.Initialized);
    Contract.Ensures(Contract.Result<bool>() && State == S.Computed ||
                     !Contract.Result<bool>() && State == S.Initialized);

    this._computedData = prefix + _data;
    _state = S.Computed;

    return true;
  }

  public string Data
  {
    get
    {
      Contract.Requires(State != S.NotReady);

      return _data;
    }
  }


  string _computedData;
  public string ComputedData
  {
    get
    {
      Contract.Requires(State == S.Computed);
      Contract.Ensures(Contract.Result<string>() != null);

      return _computedData;
    }
  }

  
}
