﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace CodeContracts.Samples
{
  static class Incrementer
  {

    public static void IncrementValue(int[] array, int val)
    {
      int i = Search.BinarySearch(array, val);

      IncrementIndex(array, i);
    }


    public static void IncrementIndex(int[] array, int index)
    {
      array[index]++;
    }
  }


}


