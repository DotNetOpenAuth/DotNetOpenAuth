﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics.Contracts;

namespace Demo
{
  class Program
  {


    static void Main(string[] args)
    {
      if (args.Length < 1) return;
      var argString = args[0];
      Contract.Assume(argString != null);

      int daysSince1980 = Int32.Parse(args[0]);
      if (daysSince1980 <= 0) return;

      int dayInYear;
      int year = ZuneDate.YearSince1980(daysSince1980, out dayInYear);

      string[] days;
      if (DateTime.IsLeapYear(year))
      {
        days = new string[366];
      }
      else
      {
        Contract.Assert(dayInYear <= 365);
        days = new string[365];
      }
      days[dayInYear - 1] = "used";

    }
  }
}
