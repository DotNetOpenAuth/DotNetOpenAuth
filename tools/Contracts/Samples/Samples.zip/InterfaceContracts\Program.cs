﻿using System;
using System.Diagnostics.Contracts;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contracts.Samples
{
  class Program
  {
    static void Main(string[] args)
    {
      var f1 = new FooImplementation1();
      int r1 = f1.Foo(0);
      Contract.Assert(r1 > 0);

      IFoo f2 = new FooImplementation2();
      int r2 = f2.Foo(1);
    }
  }

  [ContractClass(typeof(IFooContract))]
  interface IFoo
  {
    int Foo(int x);
  }

  [ContractClassFor(typeof(IFoo))]
  abstract class IFooContract : IFoo
  {
    int IFoo.Foo(int x)
    {
      Contract.Requires(x > 0);
      Contract.Ensures(Contract.Result<int>() > 0);

      throw new NotImplementedException();
    }
  }

  public class FooImplementation1 : IFoo
  {
    public int Foo(int x)
    {
      return x;
    }
  }

  public class FooImplementation2 : IFoo
  {
    /// <summary>
    /// Bad implementation of IFoo.Foo which does not always satisfy post condition.
    /// </summary>
    int IFoo.Foo(int x)
    {
      return x - 1;
    }
  }
}
