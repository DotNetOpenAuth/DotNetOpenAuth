﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;


namespace Demo
{
  public class ZuneDate
  {
 
    public static int YearSince1980(int daysSince1980, out int dayInYear)
    {
      var year = 1980;
      var daysLeft = daysSince1980;

      while (daysLeft > 365)
      {
        if (DateTime.IsLeapYear(year))
        {
          if (daysLeft > 366)
          {
            daysLeft -= 366;
            year += 1;
          }
        }
        else
        {
          daysLeft -= 365;
          year += 1;
        }
      }

      dayInYear = daysLeft;
      return year;
    }

  }
}
